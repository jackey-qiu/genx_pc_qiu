'''File: diffev.py an implementation of the differential evolution algoithm
for fitting.
Programmed by: Matts Bjorck
Last changed: 2008 11 23
'''

from numpy import *
import thread
import time

import sys, os, pickle


__parallel_loaded__ = False
_cpu_count = 1

try:
    import multiprocessing as processing
    __parallel_loaded__ = True
    _cpu_count = processing.cpu_count
except:
    try:
        import processing
        __parallel_loaded__ = True
        _cpu_count = processing.cpuCount()
    except:
        #print 'processing not installed no parallel processing possible'
        pass
    

import model

# Add current path to the system paths
# just in case some user make a directory change
sys.path.append(os.getcwd())

#==============================================================================
# class: DiffEv
class DiffEv:
    '''
    Class DiffEv
    Contains the implemenetation of the differential evolution algorithm.
    It also contains thread support which is activated by the start_fit 
    function.
    '''
    def __init__(self):
        
        # Mutation schemes implemented
        self.mutation_schemes = [self.best_1_bin, self.rand_1_bin,\
            self.best_either_or, self.rand_either_or]
            
        self.model = model.Model()
        
        self.km = 0.7 # Mutation constant
        self.kr = 0.7 # Cross over constant
        self.pf = 0.5 # probablility for mutation
        
        # Flag to choose beween the two alternatives below
        self.use_pop_mult = False
        self.pop_mult = 3 # Set the pop_size to pop_mult * # free parameters
        self.pop_size = 10 # Set the pop_size only
        
        # Flag to choose between the two alternatives below
        self.use_max_generations = False 
        self.max_generations = 500 # Use a fixed # of iterations
        self.max_generation_mult = 6 # A mult const for max number of iter
        
        # Flag to choose whether or not to use a starting guess
        self.use_start_guess = True
        # Flag to choose wheter or not to use the boundaries
        self.use_boundaries = True
        
        # Sleeping time for every generation
        self.sleep_time = 0.2
        # Allowed disagreement between the two different fom
        # evaluations
        self.fom_allowed_dis = 1e-10
        # Flag if we should use parallel processing 
        self.use_parallel_processing = __parallel_loaded__*0
        if __parallel_loaded__:
            self.processes = _cpu_count
        else:
            self.processes = 0
        self.chunksize = 1
        # Flag for using autosave
        self.use_autosave = True
        # autosave interval in generations        
        self.autosave_interval = 10
        
        # Functions that are user definable
        self.plot_output = default_plot_output
        self.text_output = default_text_output
        self.parameter_output = default_parameter_output
        self.autosave = defualt_autosave
        self.fitting_ended = default_fitting_ended
        
        
        # Definition for the create_trial function
        self.create_trial = self.best_1_bin
        
        # Control flags:
        self.running = False # true if optimization is running
        self.stop = False # true if the optimization should stop
        self.setup_ok = False # True if the optimization have been setup
        self.error = False # True/string if an error ahs occured
        
        # Logging variables
        # Maximum number of logged elements
        self.max_log = 100000
        self.fom_log = array([[0,0]])[0:0]
        #self.par_evals = array([[]])[0:0]
        
        self.par_evals = CircBuffer(self.max_log, buffer = array([[]])[0:0])
        #self.fom_evals = array([])
        self.fom_evals = CircBuffer(self.max_log)
    
    def safe_copy(self, object):
        '''safe_copy(self, object) --> None
        
        Does a safe copy of object to this object. Makes copies of everything 
        if necessary. The two objects become decoupled.
        '''
        self.km = object.km # Mutation constant
        self.kr = object.kr # Cross over constant
        self.pf = object.pf # probablility for mutation
        
        # Flag to choose beween the two alternatives below
        self.use_pop_mult = object.use_pop_mult
        self.pop_mult = object.pop_mult
        self.pop_size = object.pop_size 
        
        # Flag to choose between the two alternatives below
        self.use_max_generations = object.use_max_generations  
        self.max_generations = object.max_generations
        self.max_generation_mult = object.max_generation_mult
        
        # Flag to choose whether or not to use a starting guess
        self.use_start_guess = object.use_start_guess
        # Flag to choose wheter or not to use the boundaries
        self.use_boundaries = object.use_boundaries
        
        # Sleeping time for every generation
        self.sleep_time = object.sleep_time
        # Flag if we should use parallel processing 
        if __parallel_loaded__:
            self.use_parallel_processing = object.use_parallel_processing
        else:
            self.use_parallel_processing = False
        
        # Definition for the create_trial function
        #self.create_trial = object.create_trial
        
        # True if the optimization have been setup
        self.setup_ok = object.setup_ok 
        
        # Logging variables
        self.fom_log = object.fom_log[:]
        self.par_evals.copy_from(object.par_evals)
        self.fom_evals.copy_from(object.fom_evals)
        
        if self.setup_ok:
            self.n_pop = object.n_pop
            self.max_gen = object.max_gen
        
            # Starting values setup
            self.pop_vec = object.pop_vec
            
            self.start_guess = object.start_guess
            
            self.trial_vec = object.trial_vec
            self.best_vec = object.best_vec
            
            self.fom_vec = object.fom_vec
            self.best_fom = object.best_fom
            # Not all implementaions has these copied within their files
            # Just ignore if an error occur
            try:
                self.n_dim = object.n_dim
                self.par_min = object.par_min
                self.par_max = object.par_max
            except:
                pass
            
    def pickle_string(self, clear_evals = False):
        '''Pickle the object.

        Saves a copy into a pickled string note that the dynamic
        functions will not be saved. For normal use this is taken care of
        outside this class with the config object.
        '''
        cpy = DiffEv()
        cpy.safe_copy(self)
        if clear_evals:
            cpy.par_evals.buffer = cpy.par_evals.buffer[0:0]
            cpy.fom_evals.buffer = cpy.fom_evals.buffer[0:0]
        cpy.create_trial = None
        cpy.plot_output = None
        cpy.text_output = None
        cpy.parameter_output = None
        cpy.autosaves = None
        cpy.fitting_ended = None
        cpy.model = None
        cpy.mutation_schemes = None
        
        return pickle.dumps(cpy)
    
    def pickle_load(self, pickled_string):
        '''load_pickles(self, pickled_string) --> None
        
        Loads the pickled string into the this object. See pickle_string.
        '''
        self.safe_copy(pickle.loads(pickled_string))
        
        
    def reset(self):
        ''' reset(self) --> None
        
        Resets the optimizer. Note this has to be run if the optimizer is to
        be restarted.
        '''
        self.setup_ok = False
    
    def connect_model(self, model):
        '''connect_model(self, model) --> None
        
        Connects the model [model] to this object. Retrives the function
        that sets the variables  and stores a reference to the model.
        '''
        # Retrive parameters from the model
        (par_funcs, start_guess, par_min, par_max) = model.get_fit_pars()
        
        # Control parameter setup
        self.par_min = array(par_min)
        self.par_max = array(par_max)
        self.par_funcs = par_funcs
        self.model = model
        self.n_dim = len(par_funcs)
        if not self.setup_ok:
            self.start_guess = start_guess
    
    def init_fitting(self, model):
        '''
        Function to run before a new fit is started with start_fit.
        It initilaize the population and sets the limits on the number
        of generation and the population size.
        '''
        self.connect_model(model)
        if self.use_pop_mult:
            self.n_pop = int(self.pop_mult*self.n_dim)
        else:
            self.n_pop = int(self.pop_size)
        if self.use_max_generations:
            self.max_gen = int(self.max_generations)
        else:
            self.max_gen = int(self.max_generation_mult*self.n_dim*self.n_pop)
        
        # Starting values setup
        self.pop_vec = [self.par_min + random.rand(self.n_dim)*(self.par_max -\
         self.par_min) for i in range(self.n_pop)]
        
        if self.use_start_guess:
            self.pop_vec[0] = array(self.start_guess)
            
        self.trial_vec = [zeros(self.n_dim) for i in range(self.n_pop)]
        self.best_vec = self.pop_vec[0]
        
        self.fom_vec = zeros(self.n_dim)
        self.best_fom = 1e20

        # Logging varaibles
        self.fom_log = array([[0,1]])[0:0]
        self.par_evals = CircBuffer(self.max_log,
                                    buffer = array([self.par_min])[0:0])
        #self.fom_evals = array([])
        self.fom_evals = CircBuffer(self.max_log)
        #self.par_evals.reset(array([self.par_min])[0:0])
        #self.fom_evals.reset()
        
        self.text_output('DE initilized')
        
        # Remeber that everything has been setup ok
        self.setup_ok = True
        
    def init_fom_eval(self):
        '''init_fom_eval(self) --> None
        
        Makes the eval_fom function
        '''
        # Setting up for parallel processing
        if self.use_parallel_processing and __parallel_loaded__:
            self.text_output('Setting up a pool of workers ...')
            self.setup_parallel()
            self.eval_fom = self.calc_trial_fom_parallel
        else:
            self.eval_fom = self.calc_trial_fom
        
    def start_fit(self, model):
        '''
        Starts fitting in a seperate thred.
        '''
        # If it is not already running
        if not self.running:
            #Initilize the parameters to fit
            self.reset()
            self.init_fitting(model)
            self.init_fom_eval()
            self.stop = False
            # Start fitting in a new thread
            thread.start_new_thread(self.optimize, ())
            # For debugging
            #self.optimize()
            #self.text_output('Starting the fit...')
            #self.running = True
            return True
        else:
            self.text_output('Fit is already running, stop and then start')
            return False
        
    def stop_fit(self):
        '''
        Stops the fit if it has been started in a seperate theres 
        by start_fit.
        '''
        # If not running stop
        if self.running:
            self.stop = True
            self.text_output('Trying to stop the fit...')
        else:
            self.text_output('The fit is not running')
        
    def resume_fit(self, model):
        '''
        Resumes the fitting if has been stopped with stop_fit.
        '''
        if not self.running:
            self.stop = False
            self.connect_model(model)
            self.init_fom_eval()
            n_dim_old = self.n_dim
            if self.n_dim == n_dim_old:
                thread.start_new_thread(self.optimize, ())
                self.text_output('Restarting the fit...')
                self.running = True
                return True
            else:
                self.text_output('The number of parameters has changed'\
                ' restart the fit.')
                return False
        else:
            self.text_output('Fit is already running, stop and then start')
            return False
        
    def optimize(self):
        '''
        Method implementing the main loop of the differential evolution
        algorithm. Note that this method does not run in a separate thread.
        For threading use start_fit, stop_fit and resume_fit instead.
        '''
            
        self.text_output('Calculating start FOM ...')
        self.running = True
        self.error = False
        #print self.pop_vec
        #eval_fom()
        #self.fom_vec = self.trial_fom[:]
        # Old leftovers before going parallel
        self.fom_vec = [self.calc_fom(vec) for vec in self.pop_vec]
        #print self.fom_vec
        best_index = argmin(self.fom_vec)
        #print self.fom_vec
        #print best_index
        self.best_vec = copy(self.pop_vec[best_index])
        #print self.best_vec
        self.best_fom = self.fom_vec[best_index]
        #print self.best_fom
        if len(self.fom_log) == 0:
            self.fom_log = r_[self.fom_log,\
                                [[len(self.fom_log),self.best_fom]]]
        # Flag to keep track if there has been any improvemnts
        # in the fit - used for updates
        self.new_best = True
        
        self.text_output('Going into optimization ...')
        
        # Update the plot data for any gui or other output
        self.plot_output(self)
        self.parameter_output(self)
        
        # Just making gen live in this scope as well...
        gen = self.fom_log[-1,0] 
        for gen in range(int(self.fom_log[-1,0]) + 1, self.max_gen\
                                + int(self.fom_log[-1,0]) + 1):
            if self.stop:
                break
            
            t_start = time.time()
            
            # Create the vectors who will be compared to the 
            # population vectors
            self.trial_vec = [self.create_trial(vec) for vec in self.pop_vec]
            self.eval_fom()
            # Calculate the fom of the trial vectors and update the population
            [self.update_pop(index) for index in range(self.n_pop)]
            
            # Add the evaluation to the logging
            #self.par_evals = append(self.par_evals, self.trial_vec, axis = 0)
            [self.par_evals.append(vec, axis = 0)\
                    for vec in self.trial_vec]
            #self.fom_evals = append(self.fom_evals, self.trial_fom)
            [self.fom_evals.append(vec) for vec in self.trial_fom]
            
            # Add the best value to the fom log
            self.fom_log = r_[self.fom_log,\
                                [[len(self.fom_log),self.best_fom]]]
            
            # Let the model calculate the simulation of the best.
            sim_fom = self.calc_sim(self.best_vec)

            # Sanity of the model does the simualtions fom agree with
            # the best fom
            if abs(sim_fom - self.best_fom) > self.fom_allowed_dis:
                self.text_output('Disagrement between two different fom'
                                 ' evaluations')
                self.error = ('The disagreement between two subsequent '
                              'evaluations is larger than %s. Check the '
                              'model for circular assignments.'
                              %self.fom_allowed_dis)
                break
            
            # Update the plot data for any gui or other output
            self.plot_output(self)
            self.parameter_output(self)
            
            # Let the optimization sleep for a while
            time.sleep(self.sleep_time)
            
            # Time measurent to track the speed
            t = time.time() - t_start
            if t > 0:
                speed = self.n_pop/t
            else:
                speed = 999999
            self.text_output('FOM: %.3f Generation: %d Speed: %.1f'%\
                                (self.best_fom, gen, speed))
            
            self.new_best = False
            # Do an autosave if activated and the interval is coorect
            if gen%self.autosave_interval == 0 and self.use_autosave:
                self.autosave()

        if not self.error:
            self.text_output('Stopped at Generation: %d ...'%gen)
        
        # Lets clean up and delete our pool of workers
        if self.use_parallel_processing:
            self.dismount_parallel()
        self.eval_fom = None
        
        # Now the optimization has stopped
        self.running = False
        
        # Run application specific clean-up actions
        self.fitting_ended(self)
        
            
    def calc_fom(self, vec):
        '''
        Function to calcuate the figure of merit for parameter vector 
        vec.
        '''
        # Set the parameter values
        map(lambda func, value:func(value), self.par_funcs, vec)
        fom = self.model.evaluate_fit_func()
        
        return fom 
    
    def calc_trial_fom(self):
        '''
        Function to calculate the fom values for the trial vectors
        '''
        self.trial_fom = [self.calc_fom(vec) for vec in self.trial_vec]
    
    def calc_sim(self, vec):
        ''' calc_sim(self, vec) --> None
        Function that will evaluate the the data points for
        parameters in vec.
        '''
        # Set the paraemter values
        map(lambda func, value:func(value), self.par_funcs, vec)
        
        self.model.evaluate_sim_func()
        return self.model.fom
        
    def setup_parallel(self):
        '''setup_parallel(self) --> None
        
        setup for parallel proccesing. Creates a pool of workers with
        as many cpus there is available
        '''
        self.pool = processing.Pool(processes = self.processes,\
                        initializer = parallel_init,\
                        initargs = (self.model.pickable_copy(), ))
        self.text_output("Starting a pool with %i workers ..."%\
                            (self.processes, ))
        time.sleep(1.0)
        #print "Starting a pool with ", self.processes, " workers ..."
        
    def dismount_parallel(self):
        ''' dismount_parallel(self) --> None
        Used to close the pool and all its processes
        '''
        self.pool.close()
        self.pool.join()
        
        #del self.pool
    
    def calc_trial_fom_parallel(self):
        '''calc_trial_fom_parallel(self) --> None
        
        Function to calculate the fom in parallel using the pool
        '''
        self.trial_fom = self.pool.map(parallel_calc_fom, self.trial_vec,\
                        chunksize = self.chunksize)
    
    def calc_error_bar(self, index, fom_level):
        '''calc_error_bar(self, parameter) --> (error_bar_low, error_bar_high)
        
        Calculates the errorbar for one parameter number index. 
        returns a float tuple with the error bars. fom_level is the 
        level which is the upperboundary of the fom is allowed for the
        calculated error.
        '''
        #print self.par_evals.shape, self.par_evals
        #print self.fom_evals.shape, self.fom_evals
        if self.setup_ok: #and len(self.par_evals) != 0:
            par_values = self.par_evals[:,index]        
            #print (self.fom_evals < fom_level).sum()
            values_under_level = compress(self.fom_evals[:] <\
                                    fom_level*self.best_fom, par_values)
            #print values_under_level
            error_bar_low = values_under_level.min() - self.best_vec[index]
            error_bar_high = values_under_level.max() - self.best_vec[index]
            return (error_bar_low, error_bar_high)
        else:
            raise ErrorBarsError()
        
        
    def update_pop(self, index):
        '''
        Function to update population vector index. calcs the figure of merit
        and compares it to the current population vector and also cehecks
        if it is better than the current best.
        '''
        #fom = self.calc_fom(self.trial_vec[index])
        fom = self.trial_fom[index]
        if fom < self.fom_vec[index]:
            self.pop_vec[index] = self.trial_vec[index].copy()
            self.fom_vec[index] = fom
            if fom < self.best_fom:
                self.new_best = True
                self.best_vec = self.trial_vec[index].copy()
                self.best_fom = fom

    
    def best_1_bin(self, vec):
        '''best_1_bin(self, vec) --> trial [1D array]
        
        The default create_trial function for this class. 
        uses the best1bin method to create a new vector from the population.
        '''
        # Create mutation vector
        # Select two random vectors for the mutation
        index1 = int(random.rand(1)*self.n_pop)
        index2 = int(random.rand(1)*self.n_pop)
        # Make sure it is not the same vector 
        while index2 == index1:
            index2 = int(random.rand(1)*self.n_pop)
            
        # Calculate the mutation vector according to the best/1 scheme
        mut_vec = self.best_vec + self.km*(self.pop_vec[index1]\
         - self.pop_vec[index2])
        
        # Binomial test to detemine which parameters to change
        # given by the recombination constant kr
        recombine = random.rand(self.n_dim)<self.kr
        # Make sure at least one parameter is changed
        recombine[int(random.rand(1)*self.n_dim)]=1
        # Make the recombination
        trial = where(recombine, mut_vec, vec)
        
        # Implementation of constrained optimization
        if self.use_boundaries:
            # Check so that the parameters lie indside the bounds
            ok = bitwise_and(self.par_max > trial, self.par_min < trial)
            # If not inside make a random re-initilazation of that parameter
            trial = where(ok, trial, random.rand(self.n_dim)*\
            (self.par_max - self.par_min) + self.par_min)
        
        return trial
    
    def best_either_or(self, vec):
        '''best_either_or(self, vec) --> trial [1D array]
        
        The either/or scheme for creating a trial. Using the best vector
        as base vector.
        '''
        # Create mutation vector
        # Select two random vectors for the mutation
        index1 = int(random.rand(1)*self.n_pop)
        index2 = int(random.rand(1)*self.n_pop)
        # Make sure it is not the same vector 
        while index2 == index1:
            index2 = int(random.rand(1)*self.n_pop)
        
        if random.rand(1) < self.pf:
            # Calculate the mutation vector according to the best/1 scheme
            trial = self.best_vec + self.km*(self.pop_vec[index1]\
            - self.pop_vec[index2])
        else:
            # Trying something else out more like normal recombination
            trial = vec + self.kr*(self.pop_vec[index1]\
            + self.pop_vec[index2] - 2*vec)
        
        # Implementation of constrained optimization
        if self.use_boundaries:
            # Check so that the parameters lie indside the bounds
            ok = bitwise_and(self.par_max > trial, self.par_min < trial)
            # If not inside make a random re-initilazation of that parameter
            trial = where(ok, trial, random.rand(self.n_dim)*\
            (self.par_max - self.par_min) + self.par_min)
        
        return trial
        
    def rand_1_bin(self, vec):
        '''best_1_bin(self, vec) --> trial [1D array]
        
        The default create_trial function for this class. 
        uses the best1bin method to create a new vector from the population.
        '''
        # Create mutation vector
        # Select three random vectors for the mutation
        index1 = int(random.rand(1)*self.n_pop)
        index2 = int(random.rand(1)*self.n_pop)
        # Make sure it is not the same vector 
        while index2 == index1:
            index2 = int(random.rand(1)*self.n_pop)
        index3 = int(random.rand(1)*self.n_pop)
        while index3 == index1 or index3 == index2:
            index3 = int(random.rand(1)*self.n_pop)
            
        # Calculate the mutation vector according to the rand/1 scheme
        mut_vec = self.pop_vec[index3] + self.km*(self.pop_vec[index1]\
         - self.pop_vec[index2])
        
        # Binomial test to detemine which parameters to change
        # given by the recombination constant kr
        recombine = random.rand(self.n_dim)<self.kr
        # Make sure at least one parameter is changed
        recombine[int(random.rand(1)*self.n_dim)]=1
        # Make the recombination
        trial = where(recombine, mut_vec, vec)
        
        # Implementation of constrained optimization
        if self.use_boundaries:
            # Check so that the parameters lie indside the bounds
            ok = bitwise_and(self.par_max > trial, self.par_min < trial)
            # If not inside make a random re-initilazation of that parameter
            trial = where(ok, trial, random.rand(self.n_dim)*\
            (self.par_max - self.par_min) + self.par_min)
        
        return trial
    
    def rand_either_or(self, vec):
        '''rand_either_or(self, vec) --> trial [1D array]
        
        random base vector either/or trial scheme
        '''
        # Create mutation vector
        # Select two random vectors for the mutation
        index1 = int(random.rand(1)*self.n_pop)
        index2 = int(random.rand(1)*self.n_pop)
        # Make sure it is not the same vector 
        while index2 == index1:
            index2 = int(random.rand(1)*self.n_pop)
        index0 = int(random.rand(1)*self.n_pop)
        while index0 == index1 or index0 == index2:
            index0 = int(random.rand(1)*self.n_pop)
        
        if random.rand(1) < self.pf:
            # Calculate the mutation vector according to the best/1 scheme
            trial = self.pop_vec[index0] + self.km*(self.pop_vec[index1]\
            - self.pop_vec[index2])
        else:
            # Calculate a continous recomibination
            # Trying something else out more like normal recombination
            trial = self.pop_vec[index0] + self.kr*(self.pop_vec[index1]\
            + self.pop_vec[index2] - 2*self.pop_vec[index0])
            #trial = vec + self.kr*(self.pop_vec[index1]\
            #        + self.pop_vec[index2] - 2*vec)
        
        # Implementation of constrained optimization
        if self.use_boundaries:
            # Check so that the parameters lie indside the bounds
            ok = bitwise_and(self.par_max > trial, self.par_min < trial)
            # If not inside make a random re-initilazation of that parameter
            trial = where(ok, trial, random.rand(self.n_dim)*\
            (self.par_max - self.par_min) + self.par_min)
        
        return trial
    
    
    # Different function for acessing and setting parameters that 
    # the user should have control over.
        
    def set_text_output_func(self, func):
        '''set_text_output_func(self, func) --> None
        
        Set the output function for the text output from the optimizer.
        Should be a function that takes a string as input argument.
        The default function is a simple print statement.
        '''
        self.text_output = func
            
    def set_plot_output_func(self, func):
       '''set_plot_output_func(self, func) --> None
    
       Set the output function for the plot output from the optimizer.
       Should take the an instance of solver as input.
       The default function is no output whatsoever
       '''
       self.plot_output = func
         
    
    def set_parameter_output_func(self, func):
       '''set_parameters_output_func(self, func) --> None
    
       Set the output function for the parameters output from the optimizer.
       Should take the an instance of solver as input.
       The default function is no output whatsoever
       '''
       self.parameter_output = func
         
    
    def set_fitting_ended_func(self, func):
       '''set_fitting_ended_func(self, func) --> None
    
       Set the function when the optimizer has finsihed the fitting.
       Should take the an instance of solver as input.
       The default function is no output whatsoever
       '''
       self.fitting_ended = func

    def set_autosave_func(self, func):
        '''set_autosave_func(self, func) --> None
        
        Set the function that the optimizer uses to do an autosave
        of the current fit. Function func should not take any arguments.
        '''
        self.autosave = func

    # Some get functions
   
    def get_model(self):
        '''get_model(self) --> model
        Getter that returns the model in use in solver.
        '''
        return self.model
    
    def get_fom_log(self):
        '''get_fom_log(self) -->  fom [array]
        Returns the fom as a fcn of iteration in an array. 
        Last element last fom value
        '''
        return array(self.fom_log)
    
    def get_create_trial(self, index = False):
        '''get_create_trial(self, index = False) --> string or int
        
        returns the current create trial function name if index is False as
        a string or as index in the mutation_schemes list.
        '''
        pos = self.mutation_schemes.index(self.create_trial)
        if index:
            # return the position
            return pos
        else:
            # return the name
            return self.mutation_schemes[pos].__name__
    
    def set_km(self, val):
        '''set_km(self, val) --> None
        '''
        self.km = val
    
    def set_kr(self, val):
        '''set_kr(self, val) --> None
        '''
        self.kr = val
        
    def set_create_trial(self, val):
        '''set_create_trial(self, val) --> None
        
        Raises LookupError if the value val [string] does not correspond
        to a mutation scheme/trial function
        '''
        # Get the names of the available functions
        names = [f.__name__ for f in self.mutation_schemes]
        # Find the postion of val
        pos = names.index(val)
        self.create_trial = self.mutation_schemes[pos]
        
    def set_pop_mult(self, val):
        '''set_pop_mult(self, val) --> None
        '''
        self.pop_mult = val
    
    def set_pop_size(self, val):
        '''set_pop_size(self, val) --> None
        '''
        self.pop_size = int(val)
        
    def set_max_generations(self, val):
        '''set_max_generations(self, val) --> None
        '''
        self.max_generations = int(val)
        
    def set_max_generation_mult(self, val):
        '''set_max_generation_mult(self, val) --> None
        '''
        self.max_generation_mult = val
        
    def set_sleep_time(self, val):
        '''set_sleep_time(self, val) --> None
        '''
        self.sleep_time = val
        
    def set_max_log(self, val):
        '''Sets the maximum number of logged elements
        '''
        self.max_log = val
        
    def set_use_pop_mult(self, val):
        '''set_use_pop_mult(self, val) --> None
        '''
        self.use_pop_mult = val
        
    def set_use_max_generations(self, val):
        '''set_use_max_generations(self, val) --> None
        '''
        self.use_max_generations = val
        
    def set_use_start_guess(self, val):
        '''set_use_start_guess(self, val) --> None
        '''
        self.use_start_guess = val
    
    def set_use_boundaries(self, val):
        '''set_use_boundaries(self, val) --> None
        '''
        self.use_boundaries = val
        
    def set_use_autosave(self, val):
        '''set_use_autosave(self, val) --> None
        '''
        self.use_autosave = val
        
    def set_autosave_interval(self, val):
        '''set_autosave_interval(self, val) --> None
        '''
        self.autosave_interval = int(val)
        
    def set_use_parallel_processing(self, val):
        '''set_use_parallel_processing(self, val) --> None
        '''
        if __parallel_loaded__:
            self.use_parallel_processing = val
        else:
            self.use_parallel_processing = False
    
    def set_processes(self, val):
        '''set_processes(self, val) --> None
        '''
        self.processes = int(val)
        
    def set_chunksize(self, val):
        '''set_chunksize(self, val) --> None
        '''
        self.chunksize = int(val)

    def set_fom_allowed_dis(self, val):
        '''set_chunksize(self, val) --> None
        '''
        self.fom_allowed_dis = float(val)
        
    
#==============================================================================
# Functions that is needed for parallel processing!
def parallel_init(model_copy):
    '''parallel_init(model_copy) --> None
    
    parallel initilization of a pool of processes. The function takes a
    pickle safe copy of the model and resets the script module and the compiles
    the script and creates function to set the variables.
    '''
    global model, par_funcs
    model = model_copy
    model._reset_module()
    model.simulate()
    (par_funcs, start_guess, par_min, par_max) = model.get_fit_pars()
    #print 'Sucess!'
    
def parallel_calc_fom(vec):
    '''parallel_calc_fom(vec) --> fom (float)
    
    function that is used to calculate the fom in a parallel process.
    It is a copy of calc_fom in the DiffEv class
    '''
    global model, par_funcs
    #print 'Trying to set parameters'
    # set the parameter values in the model
    map(lambda func, value:func(value), par_funcs, vec)
    #print 'Trying to evaluate'
    # evaluate the model and calculate the fom
    fom = model.evaluate_fit_func()
        
    return fom 
    
    
#==============================================================================
def default_text_output(text):
    print text
    sys.stdout.flush()

def default_plot_output(solver):
    pass
    
def default_parameter_output(solver):
    pass
    
def default_fitting_ended(solver):
    pass
    
def defualt_autosave():
    pass

def _calc_fom(model, vec, par_funcs):
        '''
        Function to calcuate the figure of merit for parameter vector 
        vec.
        '''
        # Set the paraemter values
        map(lambda func, value:func(value), par_funcs, vec)
        
        return model.evaluate_fit_func()

#==============================================================================
# BEGIN: class CircBuffer
class CircBuffer:
    '''A buffer with a fixed length to store the logging data from the diffev 
    class. Initilized to a maximumlength after which it starts to overwrite
    the data again.
    '''
    def __init__(self, maxlen, buffer = None):
        '''Inits the class with a certain maximum length maxlen.
        '''
        self.maxlen = int(maxlen)
        self.pos = -1
        self.filled = False
        if buffer == None:
            self.buffer = zeros((self.maxlen,))
        else:
            if len(buffer) != 0:
                self.buffer = array(buffer).repeat(
                    ceil(self.maxlen/(len(buffer)*1.0)), 0)[:self.maxlen]
                self.pos = len(buffer) - 1
            else:
               self.buffer = zeros((self.maxlen,) + buffer.shape[1:])

        
    def reset(self, buffer = None):
        '''Resets the buffer to the initial state
        '''
        self.pos = -1
        self.filled = False
        #self.buffer = buffer
        if buffer == None:
             self.buffer = zeros((self.maxlen,))
        else:
            if len(buffer) != 0:
                self.buffer = array(buffer).repeat(
                    ceil(self.maxlen/(len(buffer)*1.0)), 0)[:self.maxlen]
                self.pos = len(buffer) - 1
            else:
                self.buffer = zeros((self.maxlen,) + buffer.shape[1:])


        
    def append(self, item, axis = None):
        '''Appends an element to the last position of the buffer
        '''
        new_pos = (self.pos + 1)%self.maxlen
        if len(self.buffer) >= self.maxlen:
            if self.pos >= (self.maxlen - 1):
                self.filled = True
            self.buffer[new_pos] = array(item).real
        else:
            self.buffer = append(self.buffer, item, axis = axis)
        self.pos = new_pos
        
    def array(self):
        '''returns an ordered array instead of the circular
        working version
        '''
        if self.filled:
            return r_[self.buffer[self.pos+1:], self.buffer[:self.pos+1]]
        else:
            return r_[self.buffer[:self.pos+1]]
        
    def copy_from(self, object):
        '''Add copy support
        '''
        if type(object) == type(array([])):
            self.buffer = object[-self.maxlen:]
        elif object.__class__ == self.__class__:
            # Check if the buffer has been removed.
            if len(object.buffer) == 0:
                self.__init__(object.maxlen, object.buffer)
            else:
                self.buffer = object.buffer.copy()
                self.maxlen = object.maxlen
                self.pos = object.pos
                try:
                    self.filled = object.filled
                except:
                    self.filled = False
        else:
            raise TypeError('CircBuffer support only copying from CircBuffer'\
                        ' and arrays.')
                        
                        
    def __getitem__(self, key):
        return self.array().__getitem__(key)
    
    

# END: class CircBuffer
#==============================================================================
class GenericError(Exception):
    ''' Just a empty class used for inheritance. Only useful
    to check if the errors are originating from the model library.
    All these errors are controllable. If they not originate from
    this class something has passed trough and that should be impossible '''
    pass

class ErrorBarError(GenericError):
    '''Error class for the fom evaluation'''
    def __init__(self):
        ''' __init__(self) --> None'''
        #self.error_message = error_message
    
    def __str__(self):
        text = 'Could not evaluate the error bars. A fit has to be made' +\
                'before they can be calculated'
        return text
