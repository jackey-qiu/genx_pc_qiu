version = '2.0b trunk'
